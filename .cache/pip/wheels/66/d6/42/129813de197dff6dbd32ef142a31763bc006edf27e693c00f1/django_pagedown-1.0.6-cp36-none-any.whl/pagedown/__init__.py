VERSION = ("1", "0", "6")
